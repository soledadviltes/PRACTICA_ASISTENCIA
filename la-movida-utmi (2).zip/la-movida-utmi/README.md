# La Movida de UTMI – Sitio web

Sitio de la Cooperativa Cultural La Movida de UTMI con:

- Reproductor de **YouTube en vivo** (canal @lamovidadeutmi6638)
- **Últimos videos**: los que publica el administrador y los que se suben solos al canal
- **Publicidad y auspiciantes** con banners que carga el administrador
- **Redes sociales**: Facebook con sus últimas publicaciones, más YouTube, Instagram y TikTok
- **Contacto**: WhatsApp, teléfono, email, ubicación y formulario de mensajes
- **Panel de administrador** en `/admin`

No necesita instalar paquetes. Solo requiere **Node.js 18 o más nuevo**.

## Probarlo en tu computadora

```bash
cd la-movida-utmi
ADMIN_PASSWORD="elegi-una-clave-segura" node server.js
```

Abrí http://localhost:3000 (sitio) y http://localhost:3000/admin (panel).
Usuario: `admin`. Si no definís `ADMIN_PASSWORD`, se genera una clave y se muestra en la consola la primera vez que arranca.

En Windows (PowerShell):

```powershell
$env:ADMIN_PASSWORD="elegi-una-clave-segura"; node server.js
```

## Publicarlo en internet

Necesitás un hosting que ejecute Node.js (Render, Railway, Fly.io, un VPS, etc.). Configuración:

- Comando de inicio: `node server.js`
- Variables de entorno: `ADMIN_PASSWORD` (obligatoria la primera vez) y opcionalmente `ADMIN_USER`
- **Disco persistente**: los videos, publicidades, mensajes e imágenes se guardan en la carpeta `data/`. Montá un disco persistente en esa carpeta (o apuntá `DATA_DIR` a él). Sin disco persistente, se pierde lo cargado cada vez que el servicio se reinicia.
- Usá HTTPS (los hosting mencionados lo dan automático).

## En vivo de YouTube

El reproductor usa el canal (`UCV2VO3baTqrGEc03uo6TLFA`), así que **muestra solo lo que esté en vivo** en cada momento, sin cambiar nada. Para que funcione:

1. En YouTube Studio, la transmisión debe tener activada la opción **"Permitir inserción"** (Permitir que se inserte).
2. Debe ser **pública**. Si hay varias transmisiones programadas públicas a la vez, el reproductor puede fallar: dejá pública solo la próxima.
3. Si no hay nada en vivo ni programado, YouTube no muestra video. El botón "Abrir en YouTube" queda como alternativa.

Si querés mostrar una transmisión puntual, en el panel andá a **En vivo, contacto y redes** y elegí "Un video o transmisión puntual".

## Qué se carga desde el panel

- **Videos**: título + link de YouTube.
- **Publicidad**: nombre del anunciante, imagen y link.
- **En vivo, contacto y redes**: WhatsApp (con código de país, ej. 5493884123456), teléfono, email, ubicación, Instagram, TikTok, frases de portada.
- **Mensajes**: lo que escribe la gente en el formulario.
- **Contraseña**: cambiar usuario y clave.

## Notas

- Facebook y Instagram limitan lo que se puede mostrar. Facebook se muestra con el plugin oficial de página; Instagram y TikTok quedan como botones con el link.
- Para hacer copias de seguridad, guardá la carpeta `data/`.
