'use strict';
(function () {
  const $ = s => document.querySelector(s);

  function el(tag, attrs, children) {
    const n = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (v === false || v == null) return;
      if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v === true ? '' : v);
    });
    (children || []).forEach(c => n.append(c));
    return n;
  }

  function fmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d)) return '';
    return d.toLocaleDateString('es-AR', { day: 'numeric', month: 'long', year: 'numeric' });
  }

  const ICONS = {
    "instagram": "<rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><circle cx=\"12\" cy=\"12\" r=\"4.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><circle cx=\"17.4\" cy=\"6.6\" r=\"1.2\"/>",
    "facebook": "<path d=\"M13.5 21v-8h2.7l.5-3.2h-3.2V7.9c0-.9.4-1.6 1.7-1.6h1.6V3.4c-.3 0-1.3-.2-2.4-.2-2.5 0-4.1 1.5-4.1 4.2v2.4H7.5V13h2.8v8z\"/>",
    "tiktok": "<path d=\"M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z\"/>",
    "youtube": "<path fill-rule=\"evenodd\" d=\"M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2C2 8.8 2 12 2 12s0 3.2.4 4.8a2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8c.4-1.6.4-4.8.4-4.8s0-3.2-.4-4.8zM10 15V9l5.2 3z\"/>",
    "whatsapp": "<path fill-rule=\"evenodd\" d=\"M12 2.2a9.8 9.8 0 0 0-8.4 14.9L2.3 21.8l4.8-1.3A9.8 9.8 0 1 0 12 2.2zm0 1.8a8 8 0 1 1-4.3 14.8l-.3-.2-2.8.8.8-2.7-.2-.3A8 8 0 0 1 12 4z\"/><path d=\"M8.9 7.6c.2-.4.5-.4.8-.4h.4c.1 0 .3.1.4.3l.8 1.9c.1.2 0 .4-.1.6l-.5.6c-.1.1-.1.3 0 .4.5.9 1.4 1.8 2.5 2.3.2.1.3.1.4 0l.7-.8c.1-.2.3-.2.5-.1l1.8.9c.2.1.3.2.3.4 0 .5-.2 1-.6 1.4-.5.5-1.2.6-1.9.5-3-.6-5.2-2.7-6-5.2-.3-.9 0-1.8.5-2.4z\"/>"
  };

  function shuffled(list) {
    const a = list.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }

  function videoCard(v) {
    const thumb = el('button', { class: 'thumb', type: 'button', 'aria-label': 'Reproducir: ' + v.title }, [
      el('img', { src: 'https://i.ytimg.com/vi/' + v.videoId + '/hqdefault.jpg', alt: '', loading: 'lazy' })
    ]);
    thumb.addEventListener('click', () => {
      const f = el('iframe', {
        src: 'https://www.youtube.com/embed/' + v.videoId + '?autoplay=1&rel=0',
        title: v.title, allow: 'autoplay; encrypted-media; picture-in-picture; fullscreen', allowfullscreen: true
      });
      thumb.replaceChildren(f);
      thumb.classList.add('playing');
      thumb.style.cursor = 'default';
    }, { once: true });
    const body = el('div', { class: 'card-body' }, [
      el('h3', { text: v.title }),
      v.date ? el('span', { class: 'meta', text: fmtDate(v.date) }) : null,
      v.description ? el('p', { text: v.description }) : null
    ].filter(Boolean));
    return el('article', { class: 'card' }, [thumb, body]);
  }

  /* ---------- Reproductor: en vivo si el canal transmite; si no, videos al azar ---------- */
  const IFRAME_ALLOW = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
  let settings = null, channelVideos = [], playerKey = '';

  function setPlayer(key, src, title) {
    if (key === playerKey) return;
    playerKey = key;
    $('#live-player').replaceChildren(el('iframe', { src, title, loading: 'lazy', allow: IFRAME_ALLOW, allowfullscreen: true }));
  }

  function randomPlaylist() {
    const ids = shuffled(channelVideos.map(v => v.videoId));
    return 'https://www.youtube.com/embed/' + ids[0] + '?rel=0' + (ids.length > 1 ? '&playlist=' + ids.slice(1).join(',') : '');
  }

  function setLiveUi(isLive, watchUrl) {
    const s = settings;
    $('#live-badge').hidden = !isLive;
    $('#live-title').textContent = isLive ? (s.liveTitle || 'En vivo') : 'Videos del canal';
    $('#live-lead').textContent = isLive
      ? 'Estamos transmitiendo ahora mismo. ¡Sumate!'
      : 'Ahora no estamos en vivo. Mientras tanto mirá videos del canal; cuando empecemos a transmitir, el directo aparece acá solo.';
    $('#live-yt').href = watchUrl;
    $('#shuffle').hidden = isLive || channelVideos.length < 2;
  }

  async function updateLive() {
    const s = settings;
    if (!s) return;
    const chan = s.channelUrl.replace(/\/$/, '');
    if (s.liveMode === 'video' && s.liveVideoId) {
      setLiveUi(true, 'https://www.youtube.com/watch?v=' + encodeURIComponent(s.liveVideoId));
      setPlayer('fixed:' + s.liveVideoId, 'https://www.youtube.com/embed/' + encodeURIComponent(s.liveVideoId) + '?rel=0', s.liveTitle || 'Transmisión');
      return;
    }
    let st = { live: false };
    try { st = await (await fetch('/api/live-status')).json(); } catch { /* sin dato: se asume que no hay directo */ }
    if (st.live && /^[\w-]{11}$/.test(st.videoId || '')) {
      setLiveUi(true, 'https://www.youtube.com/watch?v=' + st.videoId);
      setPlayer('live:' + st.videoId, 'https://www.youtube.com/embed/' + st.videoId + '?autoplay=1&mute=1&rel=0', s.liveTitle || 'Transmisión en vivo');
    } else if (channelVideos.length) {
      setLiveUi(false, chan);
      setPlayer('random', randomPlaylist(), 'Videos del canal');
    } else {
      setLiveUi(false, chan);
      if (playerKey !== 'none') {
        playerKey = 'none';
        $('#live-player').replaceChildren(el('div', { class: 'player-empty' }, [
          el('p', { text: 'No pudimos cargar los videos del canal en este momento.' }),
          el('a', { class: 'btn', href: chan, target: '_blank', rel: 'noopener', text: 'Ir al canal de YouTube' })
        ]));
      }
    }
  }

  function renderSocialTop(s) {
    const wa = (s.whatsapp || '').replace(/\D/g, '');
    const links = [
      ['instagram', 'Instagram', s.instagramUrl],
      ['facebook', 'Facebook', s.facebookUrl],
      ['tiktok', 'TikTok', s.tiktokUrl],
      ['youtube', 'YouTube', s.channelUrl],
      ['whatsapp', 'WhatsApp', wa ? 'https://wa.me/' + wa : '']
    ].filter(l => l[2]);
    $('#social-top').replaceChildren(...links.map(([key, label, url]) => {
      const a = el('a', { class: 'soc soc-' + key, href: url, target: '_blank', rel: 'noopener', 'aria-label': label });
      a.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true" focusable="false">' + ICONS[key] + '</svg>';
      return a;
    }));
  }

  function renderContact(s) {
    const items = [];
    if (s.whatsapp) items.push(['WhatsApp', el('a', { href: 'https://wa.me/' + s.whatsapp.replace(/\D/g, ''), target: '_blank', rel: 'noopener', text: '+' + s.whatsapp.replace(/\D/g, '') })]);
    if (s.phone) items.push(['Teléfono', el('a', { href: 'tel:' + s.phone.replace(/[^\d+]/g, ''), text: s.phone })]);
    if (s.email) items.push(['Email', el('a', { href: 'mailto:' + s.email, text: s.email })]);
    if (s.address) items.push(['Ubicación', el('span', { class: 'v', text: s.address })]);
    if (!items.length) items.push(['Contacto', el('span', { class: 'v', text: 'Escribinos con el formulario.' })]);
    $('#contact-list').replaceChildren(...items.map(([k, v]) =>
      el('li', {}, [el('span', { class: 'k', text: k }), v])));
  }

  function renderAds(ads) {
    const rail = $('#ad-list');
    if (!ads.length) {
      rail.replaceChildren(el('a', { class: 'ad-slot', href: '#contacto' }, [
        el('strong', { text: 'Tu publicidad acá' }),
        el('small', { text: 'Escribinos y sumá tu marca' })
      ]));
      return;
    }
    rail.replaceChildren(...ads.map(a => {
      const img = el('img', { src: a.image, alt: a.title, loading: 'lazy' });
      const name = el('span', { text: a.title });
      return a.link
        ? el('a', { class: 'ad', href: a.link, target: '_blank', rel: 'noopener sponsored' }, [img, name])
        : el('div', { class: 'ad' }, [img, name]);
    }));
  }

  async function init() {
    $('#year').textContent = new Date().getFullYear();
    let data;
    try {
      data = await (await fetch('/api/public')).json();
    } catch {
      $('#posts').replaceChildren(el('p', { class: 'empty', text: 'No pudimos cargar el contenido. Probá recargar la página.' }));
      return;
    }
    const s = data.settings;
    if (s.logo) {
      document.querySelectorAll('img[data-logo]').forEach(i => { i.src = s.logo; });
      $('#favicon').href = s.logo;
    }
    $('#tagline').textContent = s.tagline;
    $('#about').textContent = s.about;
    $('#channel-link').href = s.channelUrl;
    settings = s;
    renderSocialTop(s);
    renderContact(s);
    renderAds(data.ads);

    if (data.posts.length) {
      $('#posts').replaceChildren(...data.posts.map(p => videoCard(p)));
      $('#featured-block').hidden = false;
    }

    try {
      channelVideos = await (await fetch('/api/youtube-latest')).json();
    } catch { channelVideos = []; }
    if (!Array.isArray(channelVideos)) channelVideos = [];
    if (channelVideos.length) $('#channel').replaceChildren(...channelVideos.slice(0, 6).map(v => videoCard(v)));
    else $('#channel').replaceChildren(el('p', { class: 'empty', text: 'No pudimos cargar los videos del canal ahora. Mirá todo en YouTube con el botón de abajo.' }));

    await updateLive();
    setInterval(updateLive, 60 * 1000);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') updateLive(); });
    $('#shuffle').addEventListener('click', () => { playerKey = ''; updateLive(); });
  }

  $('#contact-form').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, st = $('#c-status'), btn = $('#c-send');
    const body = Object.fromEntries(new FormData(f));
    if (!body.name.trim() || !body.message.trim()) {
      st.className = 'status err'; st.textContent = 'Completá tu nombre y el mensaje.'; return;
    }
    btn.disabled = true; st.className = 'status'; st.textContent = 'Enviando...';
    try {
      const r = await fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'No se pudo enviar.');
      f.reset(); st.className = 'status ok'; st.textContent = 'Mensaje enviado. ¡Gracias por escribirnos!';
    } catch (err) {
      st.className = 'status err'; st.textContent = err.message;
    } finally { btn.disabled = false; }
  });

  init();
})();
