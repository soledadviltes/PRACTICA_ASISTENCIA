# La Movida de UTMI – Sitio web

Sitio de la Cooperativa Cultural La Movida de UTMI con:

- Reproductor de **YouTube en vivo** (canal @lamovidadeutmi6638)
- **Últimos videos**: los últimos 6 del canal, o los que elija el administrador
- **Publicidad**: barra a la derecha que acompaña al visitante, con banners que carga el administrador
- **Redes sociales**: íconos arriba (Instagram, Facebook, TikTok, YouTube y WhatsApp)
- **Contacto**: WhatsApp, teléfono, email, ubicación y formulario de mensajes
- **Panel de administrador** en `/admin`

No necesita instalar paquetes. Solo requiere **Node.js 18 o más nuevo**.

## Probarlo en tu computadora

```bash
cd la-movida-utmi
node server.js
```

Abrí http://localhost:3000 (sitio) y http://localhost:3000/admin (panel).

En Windows (PowerShell) es igual: `node server.js`.

## Crear la cuenta de administrador

La primera vez que el sitio arranca y todavía no hay ningún administrador:

1. Mirá la consola donde corre `node server.js`: muestra un **código de configuración** (ej. `35FB8CD790`).
2. Abrí `/admin` en el navegador. Aparece la pantalla **Registrar administrador**.
3. Escribí el código, elegí un usuario y una contraseña de 8 caracteres o más, y tocá **Crear cuenta de administrador**. Ya entrás al panel.

El código sirve solo para crear la primera cuenta, y deja de funcionar apenas se registra el administrador. Así nadie más puede registrarse desde internet. Si preferís un código propio, arrancá con `SETUP_CODE="tu-codigo" node server.js`.

Para sumar más administradores, entrá al panel, pestaña **Cuentas**, sección "Administradores".

Alternativa: si arrancás con `ADMIN_PASSWORD="una-clave"` (y opcionalmente `ADMIN_USER`), la cuenta se crea sola y no hace falta el registro.

Si te olvidás la contraseña y no hay otro administrador: detené el servidor, borrá el archivo `data/db.json` solo si no te importa perder lo cargado, o editá ese archivo y quitá la lista `users`; al volver a arrancar se vuelve a pedir el registro.

## En vivo de YouTube

El reproductor usa el canal (`UCV2VO3baTqrGEc03uo6TLFA`), así que **muestra solo lo que esté en vivo** en cada momento, sin cambiar nada. Para que funcione:

1. En YouTube Studio, la transmisión debe tener activada la opción **"Permitir inserción"** (Permitir que se inserte).
2. Debe ser **pública**. Si hay varias transmisiones programadas públicas a la vez, el reproductor puede fallar: dejá pública solo la próxima.
3. Si no hay nada en vivo ni programado, YouTube no muestra video. El botón "Abrir en YouTube" queda como alternativa.

Si querés mostrar una transmisión puntual, en el panel andá a **En vivo, contacto y redes** y elegí "Un video o transmisión puntual".

## Qué se carga desde el panel

- **Videos**: título + link de YouTube (se puede editar el link después). En "En vivo, contacto y redes" elegís si "Últimos videos" muestra los del canal o solo los tuyos.
- **Publicidad**: nombre del anunciante, imagen y link.
- **En vivo, contacto y redes**: WhatsApp (con código de país, ej. 5493884123456), teléfono, email, ubicación, links de Instagram, Facebook y TikTok, link del canal, frases de portada.
- **Mensajes**: lo que escribe la gente en el formulario.
- **Logo** y **Cuentas** (cambiar tu usuario y clave, y sumar o quitar administradores).

## Notas

- Las redes se muestran como íconos con el link que cargues; los que dejes vacíos no aparecen.
- Para hacer copias de seguridad, guardá la carpeta `data/`.
