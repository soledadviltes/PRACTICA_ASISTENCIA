'use strict';
(function () {
  const $ = s => document.querySelector(s);

  function el(tag, attrs, children) {
    const n = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (v === false || v == null) return;
      if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v === true ? '' : v);
    });
    (children || []).forEach(c => n.append(c));
    return n;
  }

  async function api(method, url, body) {
    const r = await fetch(url, {
      method, headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined
    });
    let j = {};
    try { j = await r.json(); } catch { /* sin cuerpo */ }
    if (r.status === 401 && url !== '/api/login' && url !== '/api/setup') { showLogin(); throw new Error('Tu sesión venció. Ingresá de nuevo.'); }
    if (!r.ok) throw new Error(j.error || 'Ocurrió un error.');
    return j;
  }

  function say(sel, msg, ok) {
    const n = $(sel); n.textContent = msg; n.className = 'status ' + (ok ? 'ok' : 'err');
  }
  const ytId = u => {
    const m = String(u).match(/(?:v=|youtu\.be\/|\/live\/|\/shorts\/|\/embed\/)([\w-]{11})/);
    return m ? m[1] : (/^[\w-]{11}$/.test(u) ? u : '');
  };
  const fmt = iso => new Date(iso).toLocaleString('es-AR', { dateStyle: 'medium', timeStyle: 'short' });

  /* ---------- Sesión ---------- */
  function showLogin() { $('#panel-view').hidden = true; $('#setup-view').hidden = true; $('#login-view').hidden = false; }
  async function showPanel(username) {
    $('#login-view').hidden = true; $('#setup-view').hidden = true; $('#panel-view').hidden = false;
    $('#w-user').value = username || '';
    await Promise.all([loadPosts(), loadAds(), loadLogo(), loadSettings(), loadMessages(), loadAdmins()]);
  }

  $('#setup-form').addEventListener('submit', async e => {
    e.preventDefault();
    if ($('#r-pass').value !== $('#r-pass2').value) { say('#r-status', 'Las contraseñas no coinciden.', false); return; }
    try {
      await api('POST', '/api/setup', { code: $('#r-code').value, username: $('#r-user').value, password: $('#r-pass').value });
      $('#setup-form').reset();
      const me = await api('GET', '/api/me');
      showPanel(me.username);
    } catch (err) { say('#r-status', err.message, false); }
  });
  $('#login-form').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await api('POST', '/api/login', { username: $('#l-user').value, password: $('#l-pass').value });
      $('#l-pass').value = '';
      const me = await api('GET', '/api/me');
      showPanel(me.username);
    } catch (err) { say('#l-status', err.message, false); }
  });
  $('#logout').addEventListener('click', async () => { await api('POST', '/api/logout', {}); showLogin(); });

  /* ---------- Pestañas ---------- */
  $('#tabs').addEventListener('click', e => {
    const b = e.target.closest('button[data-tab]'); if (!b) return;
    document.querySelectorAll('#tabs button').forEach(x => x.setAttribute('aria-selected', x === b));
    document.querySelectorAll('.panel').forEach(p => p.hidden = p.id !== 'tab-' + b.dataset.tab);
  });

  /* ---------- Videos ---------- */
  let posts = [];
  async function loadPosts() {
    const d = await (await fetch('/api/public')).json();
    posts = d.posts;
    const list = $('#post-list');
    if (!posts.length) { list.replaceChildren(el('p', { class: 'empty', text: 'Todavía no publicaste videos.' })); return; }
    list.replaceChildren(...posts.map(p => {
      const edit = el('button', { class: 'btn ghost small', type: 'button', text: 'Editar' });
      const del = el('button', { class: 'btn danger small', type: 'button', text: 'Borrar' });
      edit.addEventListener('click', () => {
        $('#p-id').value = p.id; $('#p-title').value = p.title;
        $('#p-url').value = 'https://www.youtube.com/watch?v=' + p.videoId; $('#p-desc').value = p.description || '';
        $('#p-save').textContent = 'Guardar cambios'; $('#p-cancel').hidden = false;
        $('#post-form').scrollIntoView({ behavior: 'smooth' });
      });
      del.addEventListener('click', async () => {
        if (del.dataset.sure !== '1') { del.dataset.sure = '1'; del.textContent = 'Confirmar borrado'; setTimeout(() => { del.dataset.sure = ''; del.textContent = 'Borrar'; }, 4000); return; }
        try { await api('DELETE', '/api/posts/' + p.id); loadPosts(); } catch (err) { say('#p-status', err.message, false); }
      });
      return el('div', { class: 'item' }, [
        el('img', { src: 'https://i.ytimg.com/vi/' + p.videoId + '/mqdefault.jpg', alt: '' }),
        el('div', { class: 'info' }, [el('strong', { text: p.title }), el('small', { text: fmt(p.date) })]),
        el('div', { class: 'actions' }, [edit, del])
      ]);
    }));
  }
  function resetPost() { $('#post-form').reset(); $('#p-id').value = ''; $('#p-save').textContent = 'Publicar video'; $('#p-cancel').hidden = true; }
  $('#p-cancel').addEventListener('click', resetPost);
  $('#post-form').addEventListener('submit', async e => {
    e.preventDefault();
    if (!ytId($('#p-url').value)) { say('#p-status', 'El link de YouTube no es válido.', false); return; }
    const id = $('#p-id').value;
    const body = { title: $('#p-title').value, youtube: $('#p-url').value, description: $('#p-desc').value };
    try {
      await api(id ? 'PUT' : 'POST', '/api/posts' + (id ? '/' + id : ''), body);
      resetPost(); say('#p-status', id ? 'Cambios guardados.' : 'Video publicado.', true); loadPosts();
    } catch (err) { say('#p-status', err.message, false); }
  });

  /* ---------- Publicidad ---------- */
  let ads = [];
  async function loadAds() {
    ads = await api('GET', '/api/ads');
    const list = $('#ad-list');
    if (!ads.length) { list.replaceChildren(el('p', { class: 'empty', text: 'Todavía no cargaste publicidades.' })); return; }
    list.replaceChildren(...ads.map(a => {
      const edit = el('button', { class: 'btn ghost small', type: 'button', text: 'Editar' });
      const del = el('button', { class: 'btn danger small', type: 'button', text: 'Borrar' });
      edit.addEventListener('click', () => {
        $('#a-id').value = a.id; $('#a-image').value = a.image; $('#a-title').value = a.title;
        $('#a-link').value = a.link || ''; $('#a-active').checked = a.active;
        previewAd(a.image); $('#a-save').textContent = 'Guardar cambios'; $('#a-cancel').hidden = false;
        $('#ad-form').scrollIntoView({ behavior: 'smooth' });
      });
      del.addEventListener('click', async () => {
        if (del.dataset.sure !== '1') { del.dataset.sure = '1'; del.textContent = 'Confirmar borrado'; setTimeout(() => { del.dataset.sure = ''; del.textContent = 'Borrar'; }, 4000); return; }
        try { await api('DELETE', '/api/ads/' + a.id); loadAds(); } catch (err) { say('#a-status', err.message, false); }
      });
      return el('div', { class: 'item' }, [
        el('img', { src: a.image, alt: '' }),
        el('div', { class: 'info' }, [el('strong', { text: a.title }), el('small', { text: a.active ? 'Visible en el sitio' : 'Oculta' })]),
        el('div', { class: 'actions' }, [edit, del])
      ]);
    }));
  }
  function previewAd(url) {
    $('#a-preview').replaceChildren(url ? el('img', { src: url, alt: 'Vista previa', style: 'max-width:320px;border-radius:10px' }) : '');
  }
  function resetAd() { $('#ad-form').reset(); $('#a-id').value = ''; $('#a-image').value = ''; previewAd(''); $('#a-save').textContent = 'Guardar publicidad'; $('#a-cancel').hidden = true; }
  $('#a-cancel').addEventListener('click', resetAd);

  function shrink(file, maxW, type) {
    return new Promise((resolve, reject) => {
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, maxW / img.width);
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL(type || 'image/jpeg', 0.85));
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('No se pudo leer la imagen.')); };
      img.src = url;
    });
  }
  $('#a-file').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    say('#a-status', 'Subiendo imagen...', true);
    try {
      const dataUrl = await shrink(f, 1280);
      const r = await api('POST', '/api/upload', { dataUrl });
      $('#a-image').value = r.url; previewAd(r.url); say('#a-status', 'Imagen lista.', true);
    } catch (err) { say('#a-status', err.message, false); }
  });
  $('#ad-form').addEventListener('submit', async e => {
    e.preventDefault();
    const id = $('#a-id').value;
    const body = { title: $('#a-title').value, link: $('#a-link').value, image: $('#a-image').value, active: $('#a-active').checked };
    try {
      await api(id ? 'PUT' : 'POST', '/api/ads' + (id ? '/' + id : ''), body);
      resetAd(); say('#a-status', 'Publicidad guardada.', true); loadAds();
    } catch (err) { say('#a-status', err.message, false); }
  });

  /* ---------- Logo ---------- */
  const ORIGINAL_LOGO = '/assets/logo.jpg';
  function showLogo(url) {
    $('#lg-preview').replaceChildren(el('img', { src: url, alt: 'Vista previa del logo', style: 'max-width:200px;max-height:200px;border-radius:12px;background:#fff' }));
  }
  function applyLogo(url) {
    document.querySelectorAll('img[data-logo]').forEach(i => { i.src = url; });
    $('#favicon').href = url;
  }
  async function loadLogo() {
    const s = (await (await fetch('/api/public')).json()).settings;
    $('#lg-url').value = s.logo || ORIGINAL_LOGO; showLogo($('#lg-url').value); applyLogo($('#lg-url').value);
  }
  $('#lg-file').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    say('#lg-status', 'Subiendo imagen...', true);
    try {
      const dataUrl = await shrink(f, 800, f.type === 'image/png' ? 'image/png' : 'image/jpeg');
      const r = await api('POST', '/api/upload', { dataUrl });
      $('#lg-url').value = r.url; showLogo(r.url); say('#lg-status', 'Imagen lista. Tocá "Guardar logo" para publicarla.', true);
    } catch (err) { say('#lg-status', err.message, false); }
  });
  async function saveLogo(url, msg) {
    try { await api('PUT', '/api/logo', { logo: url }); $('#lg-url').value = url; showLogo(url); applyLogo(url); say('#lg-status', msg, true); }
    catch (err) { say('#lg-status', err.message, false); }
  }
  $('#logo-form').addEventListener('submit', e => { e.preventDefault(); saveLogo($('#lg-url').value, 'Logo guardado. Ya está en el sitio.'); });
  $('#lg-reset').addEventListener('click', () => saveLogo(ORIGINAL_LOGO, 'Se volvió al logo original.'));

  /* ---------- Ajustes ---------- */
  const map = { vsrc: 'videosSource', mode: 'liveMode', vid: 'liveVideoId', ltitle: 'liveTitle', channel: 'channelId', channelurl: 'channelUrl', tagline: 'tagline', about: 'about', wa: 'whatsapp', phone: 'phone', email: 'email', addr: 'address', fb: 'facebookUrl', ig: 'instagramUrl', tt: 'tiktokUrl' };
  async function loadSettings() {
    const s = (await (await fetch('/api/public')).json()).settings;
    Object.entries(map).forEach(([f, k]) => { $('#s-' + f).value = s[k] || ''; });
  }
  $('#settings-form').addEventListener('submit', async e => {
    e.preventDefault();
    const body = {};
    Object.entries(map).forEach(([f, k]) => { body[k] = $('#s-' + f).value; });
    if (body.liveMode === 'video' && !ytId(body.liveVideoId)) { say('#s-status', 'Pegá un link o ID de YouTube válido para el video puntual.', false); return; }
    try { await api('PUT', '/api/settings', body); say('#s-status', 'Cambios guardados. Ya están en el sitio.', true); }
    catch (err) { say('#s-status', err.message, false); }
  });

  /* ---------- Mensajes ---------- */
  async function loadMessages() {
    const msgs = await api('GET', '/api/messages');
    const list = $('#msg-list');
    if (!msgs.length) { list.replaceChildren(el('p', { class: 'empty', text: 'No hay mensajes todavía.' })); return; }
    list.replaceChildren(...msgs.map(m => {
      const del = el('button', { class: 'btn danger small', type: 'button', text: 'Borrar' });
      del.addEventListener('click', async () => {
        if (del.dataset.sure !== '1') { del.dataset.sure = '1'; del.textContent = 'Confirmar borrado'; setTimeout(() => { del.dataset.sure = ''; del.textContent = 'Borrar'; }, 4000); return; }
        await api('DELETE', '/api/messages/' + m.id); loadMessages();
      });
      return el('article', { class: 'msg' }, [
        el('header', {}, [el('strong', { text: m.name + (m.email ? ' · ' + m.email : '') }), el('small', { class: 'hint', text: fmt(m.date) })]),
        el('p', { text: m.message }),
        el('div', { style: 'margin-top:10px' }, [del])
      ]);
    }));
  }

  /* ---------- Contraseña ---------- */
  $('#pw-form').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await api('POST', '/api/password', { username: $('#w-user').value, current: $('#w-cur').value, next: $('#w-new').value });
      $('#w-cur').value = ''; $('#w-new').value = ''; say('#w-status', 'Datos actualizados.', true); loadAdmins();
    } catch (err) { say('#w-status', err.message, false); }
  });

  /* ---------- Administradores ---------- */
  async function loadAdmins() {
    const admins = await api('GET', '/api/admins');
    $('#admin-list').replaceChildren(...admins.map(a => {
      const actions = el('div', { class: 'actions' });
      if (!a.me) {
        const del = el('button', { class: 'btn danger small', type: 'button', text: 'Quitar acceso' });
        del.addEventListener('click', async () => {
          if (del.dataset.sure !== '1') { del.dataset.sure = '1'; del.textContent = 'Confirmar'; setTimeout(() => { del.dataset.sure = ''; del.textContent = 'Quitar acceso'; }, 4000); return; }
          try { await api('DELETE', '/api/admins/' + a.id); loadAdmins(); } catch (err) { say('#n-status', err.message, false); }
        });
        actions.append(del);
      }
      return el('div', { class: 'item' }, [
        el('div', { class: 'info' }, [el('strong', { text: a.username }), el('small', { text: a.me ? 'Sos vos' : 'Administrador' })]),
        actions
      ]);
    }));
  }
  $('#admin-form').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await api('POST', '/api/admins', { username: $('#n-user').value, password: $('#n-pass').value });
      $('#admin-form').reset(); say('#n-status', 'Administrador agregado.', true); loadAdmins();
    } catch (err) { say('#n-status', err.message, false); }
  });

  /* ---------- Arranque ---------- */
  (async () => {
    try {
      const me = await api('GET', '/api/me');
      if (me.admin) { showPanel(me.username); return; }
      const st = await (await fetch('/api/setup-status')).json();
      if (st.needed) { $('#login-view').hidden = true; $('#setup-view').hidden = false; } else showLogin();
    } catch { showLogin(); }
  })();
})();
