'use strict';
// La Movida de UTMI - servidor sin dependencias externas (solo Node 18+).
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOADS = path.join(DATA, 'uploads');
const PUBLIC = path.join(__dirname, 'public');
const DB_FILE = path.join(DATA, 'db.json');
fs.mkdirSync(UPLOADS, { recursive: true });

/* ---------- Base de datos (archivo JSON) ---------- */
const DEFAULT_SETTINGS = {
  channelId: 'UCV2VO3baTqrGEc03uo6TLFA',
  channelUrl: 'https://www.youtube.com/@lamovidadeutmi6638',
  videosSource: 'auto', // 'auto' = últimos del canal | 'manual' = solo los que carga el administrador
  liveMode: 'channel', // 'channel' = muestra lo que esté en vivo en el canal | 'video' = un video puntual
  liveVideoId: '',
  liveTitle: 'La Movida en vivo',
  tagline: 'Cooperativa Cultural. Grupos en vivo, entrevistas y saludos musicales desde Jujuy.',
  about: 'La Movida de UTMI es una cooperativa cultural de Jujuy. En nuestro canal vas a encontrar grupos en vivo, entrevistas íntimas y emocionantes, la mejor conducción y saludos musicales.',
  facebookUrl: 'https://www.facebook.com/p/La-Movida-De-UTMI-100076532040468/',
  instagramUrl: '',
  tiktokUrl: '',
  whatsapp: '',
  phone: '',
  email: '',
  address: 'Jujuy, Argentina',
  logo: '/assets/logo.jpg'
};

function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  const h = crypto.scryptSync(pw, salt, 64).toString('hex');
  return salt + ':' + h;
}
function checkPassword(pw, stored) {
  const [salt, h] = String(stored).split(':');
  if (!salt || !h) return false;
  const test = crypto.scryptSync(pw, salt, 64);
  const real = Buffer.from(h, 'hex');
  return real.length === test.length && crypto.timingSafeEqual(real, test);
}

let db;
let setupCode = null; // solo existe mientras no haya ningún administrador
function uid() { return crypto.randomBytes(6).toString('hex'); }
function load() {
  try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { db = null; }
  if (!db) {
    db = { settings: {}, posts: [], ads: [], messages: [], users: [] };
  }
  db.settings = Object.assign({}, DEFAULT_SETTINGS, db.settings);
  db.posts = db.posts || [];
  db.ads = db.ads || [];
  db.messages = db.messages || [];
  db.users = db.users || [];
  if (db.user) { db.users.unshift({ id: uid(), username: db.user.username, pass: db.user.pass }); delete db.user; save(); }
  if (!db.users.length) {
    if (process.env.ADMIN_PASSWORD) {
      db.users.push({ id: uid(), username: process.env.ADMIN_USER || 'admin', pass: hashPassword(process.env.ADMIN_PASSWORD) });
      save();
      console.log('\nAdministrador creado con ADMIN_PASSWORD (usuario: ' + (process.env.ADMIN_USER || 'admin') + ')\n');
    } else {
      setupCode = (process.env.SETUP_CODE || crypto.randomBytes(5).toString('hex')).toUpperCase();
      console.log('\n=== Todavía no hay administrador ===');
      console.log('Abrí /admin en el navegador y registrate con este código:  ' + setupCode);
      console.log('====================================\n');
    }
  }
}
function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
load();

/* ---------- Utilidades ---------- */
const id = () => crypto.randomBytes(6).toString('hex');
const clip = (v, n) => String(v == null ? '' : v).trim().slice(0, n);

function youtubeId(input) {
  const s = String(input || '').trim();
  if (/^[\w-]{11}$/.test(s)) return s;
  const m = s.match(/(?:v=|youtu\.be\/|\/live\/|\/shorts\/|\/embed\/)([\w-]{11})/);
  return m ? m[1] : '';
}
function cleanUrl(v) {
  const s = clip(v, 500);
  if (!s) return '';
  return /^https?:\/\//i.test(s) ? s : '';
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
  '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
};

const CSP = [
  "default-src 'self'",
  "img-src 'self' data: https://i.ytimg.com https://img.youtube.com https://*.fbcdn.net",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src https://fonts.gstatic.com",
  "script-src 'self'",
  "connect-src 'self'",
  "frame-src https://www.youtube.com https://www.youtube-nocookie.com https://www.facebook.com",
  "base-uri 'self'", "form-action 'self'", "object-src 'none'"
].join('; ');

function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, Object.assign({
    'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  }, headers));
  res.end(isObj ? JSON.stringify(body) : body);
}

function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too_large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(Object.assign(new Error('bad_json'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

/* ---------- Sesiones ---------- */
const sessions = new Map(); // token -> expira
const SESSION_MS = 1000 * 60 * 60 * 12;
function cookies(req) {
  const out = {};
  String(req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function sessionUser(req) {
  const t = cookies(req).sid;
  const s = t && sessions.get(t);
  if (!s) return null;
  if (s.exp < Date.now()) { sessions.delete(t); return null; }
  const u = db.users.find(x => x.id === s.uid);
  if (!u) { sessions.delete(t); return null; }
  return u;
}
const isAdmin = req => !!sessionUser(req);
function startSession(req, user) {
  const sid = crypto.randomBytes(32).toString('base64url');
  sessions.set(sid, { exp: Date.now() + SESSION_MS, uid: user.id });
  const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
  return { 'Set-Cookie': `sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}${secure}` };
}
const sameCode = (a, b) => crypto.timingSafeEqual(crypto.createHash('sha256').update(a).digest(), crypto.createHash('sha256').update(b).digest());
const attempts = new Map(); // ip -> {n, until}
function tooMany(ip) {
  const a = attempts.get(ip);
  return a && a.n >= 5 && a.until > Date.now();
}
function failed(ip) {
  const a = attempts.get(ip) || { n: 0, until: 0 };
  a.n += 1; a.until = Date.now() + 10 * 60 * 1000;
  attempts.set(ip, a);
}

/* ---------- Últimos videos del canal (RSS de YouTube) ---------- */
let ytCache = { at: 0, items: [] };
function decodeXml(s) {
  return s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}
function fetchChannelVideos() {
  return new Promise(resolve => {
    if (Date.now() - ytCache.at < 10 * 60 * 1000) return resolve(ytCache.items);
    const url = 'https://www.youtube.com/feeds/videos.xml?channel_id=' + encodeURIComponent(db.settings.channelId);
    const req = https.get(url, { timeout: 8000, headers: { 'User-Agent': 'Mozilla/5.0 LaMovidaUTMI' } }, r => {
      if (r.statusCode !== 200) { r.resume(); return resolve(ytCache.items); }
      let xml = '';
      r.setEncoding('utf8');
      r.on('data', d => { xml += d; if (xml.length > 2e6) req.destroy(); });
      r.on('end', () => {
        const items = [];
        const re = /<entry>([\s\S]*?)<\/entry>/g;
        let m;
        while ((m = re.exec(xml)) && items.length < 15) {
          const vid = (m[1].match(/<yt:videoId>([\w-]{11})<\/yt:videoId>/) || [])[1];
          const title = (m[1].match(/<title>([\s\S]*?)<\/title>/) || [])[1];
          const date = (m[1].match(/<published>([^<]+)<\/published>/) || [])[1];
          if (vid && title) items.push({ videoId: vid, title: decodeXml(title), date: date || '' });
        }
        ytCache = { at: Date.now(), items };
        resolve(items);
      });
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(ytCache.items));
  });
}

/* ---------- ¿El canal está en vivo? ---------- */
function httpGet(url, redirects = 3) {
  return new Promise(resolve => {
    let done = false;
    const end = v => { if (!done) { done = true; resolve(v); } };
    const req = https.get(url, {
      timeout: 8000,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LaMovidaUTMI)', 'Accept-Language': 'es-AR,es;q=0.9', Cookie: 'CONSENT=YES+1; SOCS=CAI' }
    }, r => {
      if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && redirects > 0) {
        r.resume();
        let next; try { next = new URL(r.headers.location, url); } catch { return end(null); }
        if (next.protocol !== 'https:' || !/(^|\.)youtube\.com$/.test(next.hostname)) return end(null);
        return end(httpGet(next.href, redirects - 1));
      }
      if (r.statusCode !== 200) { r.resume(); return end(null); }
      let body = '';
      r.setEncoding('utf8');
      r.on('data', d => { body += d; if (body.length > 3e6) { end(body); req.destroy(); } });
      r.on('end', () => end(body));
      r.on('error', () => end(null));
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => end(null));
  });
}
let liveCache = { at: 0, data: { live: false, videoId: '' } };
async function fetchLiveStatus() {
  if (Date.now() - liveCache.at < 45 * 1000) return liveCache.data;
  const html = await httpGet('https://www.youtube.com/channel/' + encodeURIComponent(db.settings.channelId) + '/live');
  if (html == null) { liveCache.at = Date.now() - 30 * 1000; return liveCache.data; } // reintenta en 15 s
  let data = { live: false, videoId: '' };
  const canon = html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})"/);
  if (canon && /"isLiveNow":true/.test(html)) data = { live: true, videoId: canon[1] };
  liveCache = { at: Date.now(), data };
  return data;
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const method = req.method;
  const p = url.pathname;
  const ip = req.socket.remoteAddress || '';

  if (method === 'GET' && p === '/api/public') {
    return send(res, 200, {
      settings: db.settings,
      posts: db.posts.slice().sort((a, b) => b.date.localeCompare(a.date)),
      ads: db.ads.filter(a => a.active)
    });
  }
  if (method === 'GET' && p === '/api/live-status') {
    return send(res, 200, await fetchLiveStatus());
  }
  if (method === 'GET' && p === '/api/youtube-latest') {
    return send(res, 200, await fetchChannelVideos());
  }
  if (method === 'POST' && p === '/api/messages') {
    const b = await readBody(req, 20000);
    const name = clip(b.name, 80), email = clip(b.email, 120), text = clip(b.message, 2000);
    if (!name || !text) return send(res, 400, { error: 'Completá tu nombre y el mensaje.' });
    if (clip(b.website, 10)) return send(res, 200, { ok: true }); // trampa para bots
    if (db.messages.length >= 500) db.messages.pop();
    db.messages.unshift({ id: id(), name, email, message: text, date: new Date().toISOString() });
    save();
    return send(res, 200, { ok: true });
  }
  if (method === 'POST' && p === '/api/login') {
    if (tooMany(ip)) return send(res, 429, { error: 'Demasiados intentos. Probá de nuevo en unos minutos.' });
    const b = await readBody(req, 5000);
    const user = db.users.find(x => x.username === clip(b.username, 80));
    if (user && checkPassword(String(b.password || ''), user.pass)) {
      attempts.delete(ip);
      return send(res, 200, { ok: true }, startSession(req, user));
    }
    failed(ip);
    return send(res, 401, { error: 'Usuario o contraseña incorrectos.' });
  }
  if (method === 'GET' && p === '/api/setup-status') {
    return send(res, 200, { needed: db.users.length === 0 && !!setupCode });
  }
  if (method === 'POST' && p === '/api/setup') {
    if (db.users.length || !setupCode) return send(res, 403, { error: 'Ya hay un administrador registrado. Ingresá con tu usuario.' });
    if (tooMany(ip)) return send(res, 429, { error: 'Demasiados intentos. Probá de nuevo en unos minutos.' });
    const b = await readBody(req, 5000);
    if (!sameCode(String(b.code || '').trim().toUpperCase(), setupCode)) { failed(ip); return send(res, 401, { error: 'El código de configuración no es correcto.' }); }
    const name = clip(b.username, 40), pw = String(b.password || '');
    if (!/^[\w.@-]{3,40}$/.test(name)) return send(res, 400, { error: 'El usuario debe tener entre 3 y 40 caracteres, sin espacios.' });
    if (pw.length < 8) return send(res, 400, { error: 'La contraseña debe tener al menos 8 caracteres.' });
    const user = { id: uid(), username: name, pass: hashPassword(pw) };
    db.users.push(user); setupCode = null; save();
    attempts.delete(ip);
    return send(res, 200, { ok: true }, startSession(req, user));
  }
  if (method === 'POST' && p === '/api/logout') {
    sessions.delete(cookies(req).sid);
    return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
  }
  if (method === 'GET' && p === '/api/me') {
    const u = sessionUser(req);
    return send(res, 200, { admin: !!u, username: u ? u.username : null });
  }

  // ---- Desde acá, solo administrador ----
  if (!isAdmin(req)) return send(res, 401, { error: 'Iniciá sesión.' });
  const parts = p.split('/').filter(Boolean); // ['api', recurso, id]
  const resource = parts[1], rid = parts[2];

  if (resource === 'settings' && method === 'PUT') {
    const b = await readBody(req, 50000);
    const s = db.settings;
    s.channelId = clip(b.channelId, 60) || s.channelId;
    s.channelUrl = cleanUrl(b.channelUrl) || s.channelUrl;
    s.liveMode = b.liveMode === 'video' ? 'video' : 'channel';
    s.videosSource = b.videosSource === 'manual' ? 'manual' : 'auto';
    s.liveVideoId = youtubeId(b.liveVideoId);
    s.liveTitle = clip(b.liveTitle, 120);
    s.tagline = clip(b.tagline, 300);
    s.about = clip(b.about, 1200);
    s.facebookUrl = cleanUrl(b.facebookUrl);
    s.instagramUrl = cleanUrl(b.instagramUrl);
    s.tiktokUrl = cleanUrl(b.tiktokUrl);
    s.whatsapp = clip(b.whatsapp, 30).replace(/[^\d+]/g, '');
    s.phone = clip(b.phone, 40);
    s.email = clip(b.email, 120);
    s.address = clip(b.address, 200);
    ytCache.at = 0;
    save();
    return send(res, 200, s);
  }

  if (resource === 'posts' && (method === 'POST' || method === 'PUT')) {
    const b = await readBody(req, 20000);
    const vid = youtubeId(b.youtube);
    const title = clip(b.title, 150);
    if (!vid) return send(res, 400, { error: 'El link de YouTube no es válido.' });
    if (!title) return send(res, 400, { error: 'Poné un título.' });
    const data = { title, videoId: vid, description: clip(b.description, 600) };
    if (method === 'POST') {
      const post = Object.assign({ id: id(), date: new Date().toISOString() }, data);
      db.posts.unshift(post); save();
      return send(res, 200, post);
    }
    const post = db.posts.find(x => x.id === rid);
    if (!post) return send(res, 404, { error: 'No existe.' });
    Object.assign(post, data); save();
    return send(res, 200, post);
  }
  if (resource === 'posts' && method === 'DELETE') {
    db.posts = db.posts.filter(x => x.id !== rid); save();
    return send(res, 200, { ok: true });
  }

  if (resource === 'ads' && method === 'GET') return send(res, 200, db.ads);
  if (resource === 'ads' && (method === 'POST' || method === 'PUT')) {
    const b = await readBody(req, 20000);
    const title = clip(b.title, 100);
    const image = clip(b.image, 200);
    if (!title) return send(res, 400, { error: 'Poné el nombre del anunciante.' });
    if (!/^\/uploads\/[\w.-]+$/.test(image)) return send(res, 400, { error: 'Subí una imagen para la publicidad.' });
    const data = { title, image, link: cleanUrl(b.link), active: b.active !== false };
    if (method === 'POST') {
      const ad = Object.assign({ id: id(), date: new Date().toISOString() }, data);
      db.ads.unshift(ad); save();
      return send(res, 200, ad);
    }
    const ad = db.ads.find(x => x.id === rid);
    if (!ad) return send(res, 404, { error: 'No existe.' });
    Object.assign(ad, data); save();
    return send(res, 200, ad);
  }
  if (resource === 'ads' && method === 'DELETE') {
    db.ads = db.ads.filter(x => x.id !== rid); save();
    return send(res, 200, { ok: true });
  }

  if (resource === 'upload' && method === 'POST') {
    const b = await readBody(req, 8 * 1024 * 1024);
    const m = String(b.dataUrl || '').match(/^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/);
    if (!m) return send(res, 400, { error: 'Formato de imagen no válido (usá JPG, PNG o WebP).' });
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > 6 * 1024 * 1024) return send(res, 413, { error: 'La imagen es muy pesada.' });
    const name = id() + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
    fs.writeFileSync(path.join(UPLOADS, name), buf);
    return send(res, 200, { url: '/uploads/' + name });
  }

  if (resource === 'messages' && method === 'GET') return send(res, 200, db.messages);
  if (resource === 'messages' && method === 'DELETE') {
    db.messages = db.messages.filter(x => x.id !== rid); save();
    return send(res, 200, { ok: true });
  }

  if (resource === 'logo' && method === 'PUT') {
    const b = await readBody(req, 2000);
    const logo = clip(b.logo, 200);
    if (!/^\/(uploads\/[\w.-]+|assets\/logo\.jpg)$/.test(logo)) return send(res, 400, { error: 'Subí una imagen para el logo.' });
    db.settings.logo = logo; save();
    return send(res, 200, { logo });
  }

  const me = sessionUser(req);
  if (resource === 'password' && method === 'POST') {
    const b = await readBody(req, 5000);
    if (!checkPassword(String(b.current || ''), me.pass)) return send(res, 400, { error: 'La contraseña actual no es correcta.' });
    const next = String(b.next || '');
    if (next.length < 8) return send(res, 400, { error: 'La nueva contraseña debe tener al menos 8 caracteres.' });
    const name = clip(b.username, 40);
    if (name) {
      if (!/^[\w.@-]{3,40}$/.test(name)) return send(res, 400, { error: 'El usuario debe tener entre 3 y 40 caracteres, sin espacios.' });
      if (db.users.some(x => x.id !== me.id && x.username.toLowerCase() === name.toLowerCase())) return send(res, 400, { error: 'Ese usuario ya existe.' });
      me.username = name;
    }
    me.pass = hashPassword(next);
    save();
    return send(res, 200, { ok: true });
  }

  if (resource === 'admins' && method === 'GET') {
    return send(res, 200, db.users.map(u => ({ id: u.id, username: u.username, me: u.id === me.id })));
  }
  if (resource === 'admins' && method === 'POST') {
    const b = await readBody(req, 5000);
    const name = clip(b.username, 40), pw = String(b.password || '');
    if (!/^[\w.@-]{3,40}$/.test(name)) return send(res, 400, { error: 'El usuario debe tener entre 3 y 40 caracteres, sin espacios.' });
    if (pw.length < 8) return send(res, 400, { error: 'La contraseña debe tener al menos 8 caracteres.' });
    if (db.users.some(x => x.username.toLowerCase() === name.toLowerCase())) return send(res, 400, { error: 'Ese usuario ya existe.' });
    if (db.users.length >= 20) return send(res, 400, { error: 'Llegaste al máximo de administradores.' });
    db.users.push({ id: uid(), username: name, pass: hashPassword(pw) }); save();
    return send(res, 200, { ok: true });
  }
  if (resource === 'admins' && method === 'DELETE') {
    if (rid === me.id) return send(res, 400, { error: 'No podés borrar tu propia cuenta.' });
    db.users = db.users.filter(x => x.id !== rid); save();
    return send(res, 200, { ok: true });
  }

  return send(res, 404, { error: 'No encontrado.' });
}

/* ---------- Archivos estáticos ---------- */
function serveFile(res, file, cache) {
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, 'No encontrado');
    const ext = path.extname(file).toLowerCase();
    send(res, 200, buf, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': cache,
      'Content-Security-Policy': CSP
    });
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Método no permitido');

    let p = decodeURIComponent(url.pathname);
    if (p === '/admin') p = '/admin.html';
    if (p === '/') p = '/index.html';
    if (p.includes('\0')) return send(res, 400, 'Solicitud inválida');

    if (p.startsWith('/uploads/')) {
      const f = path.join(UPLOADS, path.basename(p));
      return serveFile(res, f, 'public, max-age=2592000');
    }
    const f = path.normalize(path.join(PUBLIC, p));
    if (!f.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Prohibido');
    return serveFile(res, f, p.startsWith('/assets/') ? 'public, max-age=86400' : 'no-cache');
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    send(res, status, { error: status === 413 ? 'El archivo es demasiado grande.' : status === 400 ? 'Solicitud inválida.' : 'Error del servidor.' });
  }
});

server.listen(PORT, () => console.log('La Movida de UTMI escuchando en http://localhost:' + PORT));
