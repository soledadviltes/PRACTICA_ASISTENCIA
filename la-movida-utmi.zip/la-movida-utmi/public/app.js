'use strict';
(function () {
  const $ = s => document.querySelector(s);

  function el(tag, attrs, children) {
    const n = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (v === false || v == null) return;
      if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v === true ? '' : v);
    });
    (children || []).forEach(c => n.append(c));
    return n;
  }

  function fmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d)) return '';
    return d.toLocaleDateString('es-AR', { day: 'numeric', month: 'long', year: 'numeric' });
  }

  function videoCard(v) {
    const thumb = el('button', { class: 'thumb', type: 'button', 'aria-label': 'Reproducir: ' + v.title }, [
      el('img', { src: 'https://i.ytimg.com/vi/' + v.videoId + '/hqdefault.jpg', alt: '', loading: 'lazy' })
    ]);
    thumb.addEventListener('click', () => {
      const f = el('iframe', {
        src: 'https://www.youtube.com/embed/' + v.videoId + '?autoplay=1&rel=0',
        title: v.title, allow: 'autoplay; encrypted-media; picture-in-picture; fullscreen', allowfullscreen: true
      });
      thumb.replaceChildren(f);
      thumb.classList.add('playing');
      thumb.style.cursor = 'default';
    }, { once: true });
    const body = el('div', { class: 'card-body' }, [
      el('h3', { text: v.title }),
      v.date ? el('span', { class: 'meta', text: fmtDate(v.date) }) : null,
      v.description ? el('p', { text: v.description }) : null
    ].filter(Boolean));
    return el('article', { class: 'card' }, [thumb, body]);
  }

  function renderLive(s) {
    $('#live-title').textContent = s.liveTitle || 'En vivo';
    const src = (s.liveMode === 'video' && s.liveVideoId)
      ? 'https://www.youtube.com/embed/' + encodeURIComponent(s.liveVideoId) + '?rel=0'
      : 'https://www.youtube.com/embed/live_stream?channel=' + encodeURIComponent(s.channelId) + '&rel=0';
    $('#live-player').replaceChildren(el('iframe', {
      src, title: s.liveTitle || 'Transmisión en vivo', loading: 'lazy',
      allow: 'autoplay; encrypted-media; picture-in-picture; fullscreen', allowfullscreen: true
    }));
    $('#live-yt').href = (s.liveMode === 'video' && s.liveVideoId)
      ? 'https://www.youtube.com/watch?v=' + encodeURIComponent(s.liveVideoId)
      : s.channelUrl.replace(/\/$/, '') + '/live';
  }

  function renderSocial(s) {
    const links = [
      ['YouTube', s.channelUrl, 'Canal oficial'],
      ['Facebook', s.facebookUrl, 'Novedades y fotos'],
      ['Instagram', s.instagramUrl, 'Fotos y reels'],
      ['TikTok', s.tiktokUrl, 'Videos cortos']
    ].filter(l => l[1]);
    $('#social-links').replaceChildren(...links.map(([name, url, sub]) =>
      el('a', { href: url, target: '_blank', rel: 'noopener' }, [
        el('span', {}, [name, el('small', { text: sub })])
      ])));
    const box = $('#fb-box');
    if (s.facebookUrl && /facebook\.com/.test(s.facebookUrl)) {
      const w = Math.min(500, Math.max(280, Math.floor(box.clientWidth || 400)));
      const u = 'https://www.facebook.com/plugins/page.php?href=' + encodeURIComponent(s.facebookUrl) +
        '&tabs=timeline&width=' + w + '&height=600&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=false';
      box.replaceChildren(el('iframe', { src: u, title: 'Últimas publicaciones de Facebook', loading: 'lazy', allow: 'encrypted-media' }));
    } else {
      box.hidden = true;
    }
  }

  function renderContact(s) {
    const items = [];
    if (s.whatsapp) items.push(['WhatsApp', el('a', { href: 'https://wa.me/' + s.whatsapp.replace(/\D/g, ''), target: '_blank', rel: 'noopener', text: '+' + s.whatsapp.replace(/\D/g, '') })]);
    if (s.phone) items.push(['Teléfono', el('a', { href: 'tel:' + s.phone.replace(/[^\d+]/g, ''), text: s.phone })]);
    if (s.email) items.push(['Email', el('a', { href: 'mailto:' + s.email, text: s.email })]);
    if (s.address) items.push(['Ubicación', el('span', { class: 'v', text: s.address })]);
    if (!items.length) items.push(['Contacto', el('span', { class: 'v', text: 'Escribinos con el formulario.' })]);
    $('#contact-list').replaceChildren(...items.map(([k, v]) =>
      el('li', {}, [el('span', { class: 'k', text: k }), v])));
  }

  function renderAds(ads) {
    const box = $('#ads');
    if (!ads.length) {
      box.replaceChildren(el('p', { class: 'empty', text: 'Pronto vas a ver acá a quienes nos acompañan.' }));
      return;
    }
    box.replaceChildren(...ads.map(a => {
      const img = el('img', { src: a.image, alt: a.title, loading: 'lazy' });
      const label = el('span', { text: a.title });
      return a.link
        ? el('a', { class: 'ad', href: a.link, target: '_blank', rel: 'noopener sponsored' }, [img, label])
        : el('div', { class: 'ad' }, [img, label]);
    }));
  }

  async function init() {
    $('#year').textContent = new Date().getFullYear();
    let data;
    try {
      data = await (await fetch('/api/public')).json();
    } catch {
      $('#posts').replaceChildren(el('p', { class: 'empty', text: 'No pudimos cargar el contenido. Probá recargar la página.' }));
      return;
    }
    const s = data.settings;
    $('#tagline').textContent = s.tagline;
    $('#about').textContent = s.about;
    $('#channel-link').href = s.channelUrl;
    renderLive(s);
    renderSocial(s);
    renderContact(s);
    renderAds(data.ads);

    const posts = $('#posts');
    if (data.posts.length) posts.replaceChildren(...data.posts.map(p => videoCard(p)));
    else posts.replaceChildren(el('p', { class: 'empty', text: 'Todavía no hay publicaciones. Mirá los videos del canal más abajo.' }));

    try {
      const latest = await (await fetch('/api/youtube-latest')).json();
      const shown = new Set(data.posts.map(p => p.videoId));
      const fresh = latest.filter(v => !shown.has(v.videoId));
      if (fresh.length) {
        $('#channel').replaceChildren(...fresh.map(v => videoCard(v)));
        $('#channel-block').hidden = false;
      }
    } catch { /* el canal es opcional */ }
  }

  $('#contact-form').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, st = $('#c-status'), btn = $('#c-send');
    const body = Object.fromEntries(new FormData(f));
    if (!body.name.trim() || !body.message.trim()) {
      st.className = 'status err'; st.textContent = 'Completá tu nombre y el mensaje.'; return;
    }
    btn.disabled = true; st.className = 'status'; st.textContent = 'Enviando...';
    try {
      const r = await fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'No se pudo enviar.');
      f.reset(); st.className = 'status ok'; st.textContent = 'Mensaje enviado. ¡Gracias por escribirnos!';
    } catch (err) {
      st.className = 'status err'; st.textContent = err.message;
    } finally { btn.disabled = false; }
  });

  init();
})();
