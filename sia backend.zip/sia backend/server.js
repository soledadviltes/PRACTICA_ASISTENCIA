const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// Endpoint de prueba
app.get('/api/test', (req, res) => {
    res.json({ mensaje: 'Backend del SIA funcionando correctamente' });
});

// Endpoint: Iniciar Clase y Generar QR
app.post('/api/clases/iniciar', async (req, res) => {
    const { materia_id, hora_inicio, hora_fin } = req.body;
    const fecha_hoy = new Date().toISOString().split('T')[0];
    const codigo_qr = `CLASE-${materia_id}-${Date.now()}`;

    try {
        const [result] = await db.query(
            'INSERT INTO clases (materia_id, fecha, hora_inicio, hora_fin, codigo_qr) VALUES (?, ?, ?, ?, ?)',
            [materia_id, fecha_hoy, hora_inicio, hora_fin, codigo_qr]
        );

        res.json({
            mensaje: 'Clase iniciada correctamente',
            clase_id: result.insertId,
            codigo_qr: codigo_qr
        });
    } catch (error) {
        console.error('Error al iniciar clase:', error);
        res.status(500).json({ error: 'Error al iniciar la clase' });
    }
});

// Endpoint: Registrar Asistencia del Alumno
app.post('/api/asistencias/registrar', async (req, res) => {
    const { alumno_id, codigo_qr } = req.body;

    try {
        const [clases] = await db.query('SELECT id FROM clases WHERE codigo_qr = ?', [codigo_qr]);
        
        if (clases.length === 0) {
            return res.status(404).json({ error: 'Código QR no válido o clase inexistente' });
        }

        const clase_id = clases[0].id;

        const [existente] = await db.query(
            'SELECT id FROM asistencias WHERE alumno_id = ? AND clase_id = ?',
            [alumno_id, clase_id]
        );

        if (existente.length > 0) {
            return res.status(400).json({ error: 'Ya has registrado tu asistencia en esta clase' });
        }

        await db.query(
            'INSERT INTO asistencias (alumno_id, clase_id, fecha_registro, estado) VALUES (?, ?, NOW(), ?)',
            [alumno_id, clase_id, 'Presente']
        );

        res.json({ mensaje: 'Asistencia registrada con éxito' });
    } catch (error) {
        console.error('Error al registrar asistencia:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

// Endpoint: Obtener el listado general de asistencias
app.get('/api/asistencias', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM asistencias ORDER BY id DESC');
        res.json(rows);
    } catch (error) {
        console.error('Error al obtener asistencias:', error);
        res.status(500).json({ error: 'Error al consultar asistencias' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor SIA ejecutándose en http://localhost:${PORT}`);
});